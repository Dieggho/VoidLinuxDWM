#!/bin/sh
/home/$USER/.fehbg &
slstatus &
xcompmgr &